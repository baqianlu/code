package com.vaemc.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private Button btnSwitch;
    private Button btnNum1;
    private Button btnNum2;
    private Button btnNum3;
    private String device_id="684134736";
    private String api_key="aRKrT7YLOaujgmBDxLelHW1X2b8=";
    OkHttpClient client = new OkHttpClient();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();





        btnSwitch.setOnClickListener((v -> {
            if (btnSwitch.getText().equals("ON")) {
                new Thread(()->{
                    try {
                        post("http://api.heclouds.com/cmds?device_id="+device_id,"255");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }).start();



                btnSwitch.setText("OFF");
            } else if (btnSwitch.getText().equals("OFF")) {
                new Thread(()->{
                    try {
                        post("http://api.heclouds.com/cmds?device_id="+device_id,"0");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }).start();
                btnSwitch.setText("ON");
            }


        }));

        btnNum1.setOnClickListener((v -> {
            new Thread(()->{
                try {
                    post("http://api.heclouds.com/cmds?device_id="+device_id,"255");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();
            btnSwitch.setText("OFF");
        }));
        btnNum2.setOnClickListener((v -> {
            new Thread(()->{
                try {
                    post("http://api.heclouds.com/cmds?device_id="+device_id,"120");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();
            btnSwitch.setText("OFF");
        }));
        btnNum3.setOnClickListener((v -> {
            new Thread(()->{
                try {
                    post("http://api.heclouds.com/cmds?device_id="+device_id,"55");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }).start();
            btnSwitch.setText("OFF");


        }));
    }

    public static final MediaType JSON
            = MediaType.get("application/json; charset=utf-8");

    String post(String url, String json) throws IOException {
        RequestBody body = RequestBody.create(JSON, json);
        Request request = new Request.Builder()
                .addHeader("api-key",api_key)
                .url(url)
                .post(body)
                .build();
        try (Response response = client.newCall(request).execute()) {
            return response.body().string();
        }
    }
    private void initView() {
        btnSwitch = (Button) findViewById(R.id.btn_switch);
        btnNum1 = (Button) findViewById(R.id.btn_num_1);
        btnNum2 = (Button) findViewById(R.id.btn_num_2);
        btnNum3 = (Button) findViewById(R.id.btn_num_3);
    }
}